/*
 * common sampling module code for sampling
 *
 * Copyright (c) 2009 Goole, Inc
 * Contributed by Stephane Eranian <eranian@gmail.com>
 *
 * This file is part of pfmon, a sample tool to measure performance 
 * of applications on Linux.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 * 02111-1307 USA
 */
#ifndef __PFMON_SMPL_UTIL_H__
#define __PFMON_SMPL_UTIL_H__

typedef struct {
	pfmon_hash_key_t key;
	uint64_t count[PFMON_MAX_PMDS];
	uint64_t *buckets;
	uint64_t start, end;
	uint64_t cookie;
	char *mod;
} hash_data_t;

extern void smpl_reduce(pfmon_sdesc_t *sdesc, hash_data_t **tab, unsigned long num_entries, unsigned int event_count);
#endif /* __PFMON_SMPL_UTIL_H__ */
